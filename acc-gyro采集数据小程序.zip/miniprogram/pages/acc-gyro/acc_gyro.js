// pages/acc/acc.js
const app = getApp()
//获取数据库引用
const db = wx.cloud.database({ env: 'homework-5gvcd' });
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: 0,
    accelerometerX: null,
    accelerometerY: null,
    accelerometerZ: null,
    accXs: [],
    accYs: [],
    accZs: [],
    gyroXs:[],
    gyroYs:[],
    gyroZs:[],
    gyroscopeX:null,
    gyroscopeY:null,
    gyroscopeZ:null,
    AtimeSs: [],
    GtimeSs:[],
    startTime: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      height:options.height,
      weight:options.weight,
      year:options.year,
      gender:options.gender,
      yundong:options.yundong
    })
  },

  startAccelerometer: function (e) {
    wx.startAccelerometer({
      interval: 'game',
      success: res => { console.log("加速计调用成功"); },
      fail: res => { console.log(res) }
    });
    wx.startGyroscope({
      interval: 'game',
      success: res => { console.log("陀螺仪调用成功"); },
      fail: res => { console.log(res) }
    })
    this.setData({ startTime: new Date().getTime()})
    let _this = this;
    _this.setData({ isReading: true })
    let accXs = [];
    let accYs = [];
    let accZs = [];
    let AtimeSs = [];
    let gyroXs = [];
    let gyroYs = [];
    let gyroZs = [];
    let GtimeSs = [];
    // 监听加速度数据
    wx.onAccelerometerChange(function (res) {
      let mid_time = new Date().getTime();
      // console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
      // console.log(res.x, res.y, res.z, mid_time )
      let timeStep = (mid_time - _this.data.startTime) / 1000
      _this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep)});
      if (timeStep < 15) {
        // console.log("timeStep < 10")
        accXs.push(res.x)
        accYs.push(res.y)
        accZs.push(res.z)
        AtimeSs.push(mid_time)
        _this.setData({
          accelerometerX: parseFloat(res.x.toFixed(5)),
          accelerometerY: parseFloat(res.y.toFixed(5)),
          accelerometerZ: parseFloat(res.z.toFixed(5))
        })
      } 
      if (timeStep >= 15) {
        // console.log("timeStep = 10")
        _this.setData({ value: 150, displayValue: 15});
        _this.stopAccelerometer();
        // console.log("end-time: ", Date.now())
        _this.setData({ accXs: accXs, accYs: accYs, accZs: accZs, AtimeSs: AtimeSs })
        return;
      }
    })
    wx.onGyroscopeChange(function (res) {
      let mid_time2 = new Date().getTime();
      // console.log("mid-time: ", mid_time, "startTime: ", _this.data.startTime)
      // console.log(res.x, res.y, res.z, mid_time )
      let timeStep = (mid_time2 - _this.data.startTime) / 1000
      _this.setData({ value: parseInt(timeStep * 10), displayValue: parseInt(timeStep)});
      if (timeStep < 15) {
        // console.log("timeStep < 10")
        gyroXs.push(res.x)
        gyroYs.push(res.y)
        gyroZs.push(res.z)
        GtimeSs.push(mid_time2)
        _this.setData({
          gyroscopeX: parseFloat(res.x.toFixed(5)),
          gyroscopeY: parseFloat(res.y.toFixed(5)),
          gyroscopeZ: parseFloat(res.z.toFixed(5))
        })
      } 
      if (timeStep >= 15) {
        // console.log("timeStep = 10")
        _this.setData({ value: 150, displayValue: 15});
        _this.stopGyroscope();
        // console.log("end-time: ", Date.now())
        _this.setData({ gyroXs: gyroXs, gyroYs: gyroYs, gyroZs: gyroZs, GtimeSs: GtimeSs })
        return;
      }
    })
  },

  stopAccelerometer: function () {
    let _this = this
    this.setData({ isReading: false})
    wx.stopAccelerometer({
      success: res => {
        console.log("加速计停止读取")
        _this.setData({ accelerometerX: null, accelerometerY: null, accelerometerZ: null, activity: null })
      }
    })
  },
  stopGyroscope: function () {
    let _this = this
    this.setData({ isReading: false })
    wx.stopGyroscope({
      success: res => {
        console.log("陀螺仪停止读取")
        _this.setData({ gyroscopeX: null, gyroscopeY: null, gyroscopeZ: null, activity: null })
      }
    })
  },
  stopSensor:function(){
    this.stopGyroscope();
    this.stopAccelerometer();
  },
  saveAcc() {
    console.log("save...")
    let accXs = this.data.accXs, accYs = this.data.accYs, accZs = this.data.accZs, AtimeSs = this.data.AtimeSs;
    let gyroXs = this.data.gyroXs, gyroYs = this.data.gyroYs, gyroZs = this.data.gyroZs, GtimeSs = this.data.GtimeSs;
    let year=this.data.year, height=this.data.height, weight=this.data.weight, gender=this.data.gender;
    if(this.data.yundong=='kaihetiao'){
      console.log('开合跳')
      db.collection('kaihetiao').add({
        data: { accXs: accXs, accYs: accYs, accZs: accZs, AtimeSs: AtimeSs, gyroXs: gyroXs, gyroYs: gyroYs, gyroZs: gyroZs,GtimeSs: GtimeSs, year:year,height:height,weight:weight,gender:gender,yundong:this.data.yundong}
      })
      .then(res => { console.log("保存成功") ;
        wx.showToast({
          title: '保存成功',
        })
      })
      .catch(res => { console.log("保存失败") ;
    wx.showToast({
      title: '保存失败',
      icon:"none"
    }) })
    }
    if(this.data.yundong=='hezhangtiao'){
      console.log('合掌跳')
      db.collection('hezhangtiao').add({
        data: { accXs: accXs, accYs: accYs, accZs: accZs, AtimeSs: AtimeSs, gyroXs: gyroXs, gyroYs: gyroYs, gyroZs: gyroZs,GtimeSs: GtimeSs, year:year,height:height,weight:weight,gender:gender,yundong:this.data.yundong}
      })
      .then(res => { console.log("保存成功") ;
        wx.showToast({
          title: '保存成功',
        })
      })
      .catch(res => { console.log("保存失败");
    wx.showToast({
      title: '保存失败',
      icon:"none"
    }) })
    }
    if(this.data.yundong=='shendun'){
      console.log('深蹲')
      db.collection('shendun').add({
        data: { accXs: accXs, accYs: accYs, accZs: accZs, AtimeSs: AtimeSs, gyroXs: gyroXs, gyroYs: gyroYs, gyroZs: gyroZs,GtimeSs: GtimeSs, year:year,height:height,weight:weight,gender:gender,yundong:this.data.yundong}
      })
      .then(res => { console.log("保存成功") ;
        wx.showToast({
          title: '保存成功',
        })
      })
      .catch(res => { console.log("保存失败") ;
    wx.showToast({
      title: '保存失败',
      icon:"none"
    })})
    }
    if(this.data.yundong=='gaotaitui'){
      console.log('高抬腿')
      db.collection('gaotaitui').add({
        data: { accXs: accXs, accYs: accYs, accZs: accZs, AtimeSs: AtimeSs, gyroXs: gyroXs, gyroYs: gyroYs, gyroZs: gyroZs,GtimeSs: GtimeSs, year:year,height:height,weight:weight,gender:gender,yundong:this.data.yundong}
      })
      .then(res => { console.log("保存成功") ;
        wx.showToast({
          title: '保存成功',
        })
      })
      .catch(res => { console.log("保存失败");
    wx.showToast({
      title: '保存失败',
      icon:"none"
    }) })
    }
  },
})