// miniprogram/pages/homepage/homepage.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
height:null,
year:null,
weight:null,
gender:null
  },
  inputCM(event) {
       this.setData({
         height: event.detail.value
       })
     },
  inputYear(event){
    this.setData({
      year: event.detail.value
    })
  },
  inputKG(event){
    this.setData({
      weight: event.detail.value
    })
  },
  inputGender(event){
    this.setData({
      gender: event.detail.value
    })
  },
  kaihetiao(){
    wx.navigateTo({
      url: '../acc-gyro/acc_gyro?yundong=kaihetiao&height='+this.data.height+'&year='+this.data.year+'&weight='+this.data.weight+'&gender='+this.data.gender,
    })
  },
  hezhangtiao(){
    wx.navigateTo({
      url: '../acc-gyro/acc_gyro?yundong=hezhangtiao&height='+this.data.height+'&year='+this.data.year+'&weight='+this.data.weight+'&gender='+this.data.gender,
    })
  },
  shendun(){
    wx.navigateTo({
      url: '../acc-gyro/acc_gyro?yundong=shendun&height='+this.data.height+'&year='+this.data.year+'&weight='+this.data.weight+'&gender='+this.data.gender,
    })
  },
  gaotaitui(){
    wx.navigateTo({
      url: '../acc-gyro/acc_gyro?yundong=gaotaitui&height='+this.data.height+'&year='+this.data.year+'&weight='+this.data.weight+'&gender='+this.data.gender,
    })
  }
})